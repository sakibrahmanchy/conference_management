@extends('layouts.master')






@section('content')

<div class = "jumbotron">
<h1>Thank you very much!!</h1>.<p class = "alert alert-success"> Your request has been sent to admin. Please visit us again for confirmation!!</p>
</div>

@stop