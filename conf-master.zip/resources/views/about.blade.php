@extends('layouts.master')

@section('title')
  About Page
@stop

@section('content')
   About
@stop