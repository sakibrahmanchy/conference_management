<html style = "height: 100%;box-sizing: border-box;">
    <div style="position: absolute; right: 0;bottom: 0;left: 0;padding: 1rem;background-color:  #204d74; color:white;text-align: center;"  >
      <p>Copyright © conf-master.org</p>
    </div>
</html>