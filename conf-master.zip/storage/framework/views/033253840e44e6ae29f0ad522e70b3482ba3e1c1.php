<?php $__env->startSection('title'); ?>
    Account
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" ><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
  <li role="presentation" class = "active"><a href="<?php echo e(route('account')); ?>">Account <span class="badge"></span></a></li>
   <li role="presentation"><a href="<?php echo e(route('getContact')); ?>">Contact <span class="badge"></span></a></li>
</ul>

<br>
        <div class = "col-md-6 col-md-offset-3 jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
            <header class = ""><h1>Your Account</h1></header>
                <?php if(Storage::disk('local')->has($user->userID.'.jpg')): ?>
        <section class = "row new-post">
            <div class = "col-md-6 col-md-offset-3">
                <img src="<?php echo e(route('account.image',['filename' => $user->userID . '.jpg'])); ?>" alt="" class="img-responsive"/>
            </div>
        </section>
    <?php endif; ?>
             <form action="<?php echo e(route('account.save')); ?>" method="post" enctype="multipart/form-data">

                <br><div class = "form-group">
                    <label for="name">Name</label>
                    <input type="text" name = "name" class = "form-control" value = "<?php echo e($user->name); ?>" id = "name"/>
                </div>
                 <div class = "form-group">
                    <label for="presentDesignation">Present Designation</label>
                    <input type="text" name = "presentDesignation" class = "form-control" value = "<?php echo e($user->presentDesignation); ?>" id = "presentDesignation"/>
                </div>

                 <div class = "form-group">
                    <label for="payScale">Payscale</label>
                    <input type="text" name = "payScale" class = "form-control" value = "<?php echo e($user->payScale); ?>" id = "payScale"/>
                </div>
                <div class = "form-group">
                    <label for="phone">Phone</label>
                    <input type="text" name = "phone" class = "form-control" value = "<?php echo e($user->phone); ?>" id = "phone"/>
                </div>

                <div class = "form-group">
                    <label for="image">Image(only .jpg)</label>
                    <input type="file" name = "image" class = "form-control" id = "image"/>
                </div>
                <button type = "submit" class = "btn btn-primary">Save Account</button>
                <input type="hidden" value = "<?php echo e(Session::token()); ?>" name = "_token"/>
             </form>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>