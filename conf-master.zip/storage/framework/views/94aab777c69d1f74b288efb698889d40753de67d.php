<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">

  <li role="presentation"><a href="<?php echo e(route('user.requests')); ?>">User Requests <span class="badge"><?php echo e($requests); ?></span></a></li>
  
</ul>

<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br>
    <section class = 'row new-post'>
        <div class="col-md-6 col-md-offset-3 jumbotron" style = "background-color: #204d74; color: #f5f5f5;"  >
            <header><h3>Create a new advertisement!</h3></header>
            <form action="<?php echo e(route('advertise.post')); ?>" method="post">
                <div class="form-group" >
                    <label for="houseNo">House to be alloted:</label>
                    <select class="form-control" name = "houseNo" required>
                       <option selected="" value = "0">Select House no. from list</option>
                       <?php /*<?php foreach($allotmentStatus as $status): ?>
                            <option value="<?php echo e($status->houseName); ?>"><?php echo e($status->houseName); ?></option>
                       <?php endforeach; ?>*/ ?>
                    </select>
                    <br>
                    <label for="comments">House description:</label>
                    <textarea class = "form-control <?php echo e($errors->has('houseDess')?'has-error':''); ?>" name="comments" cols="5" placeholder="Additional comments for user advantages" ></textarea>
                    <br>
                </div>

                <button type="submit" class="btn btn-primary" >Create Post!</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
            </form>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>