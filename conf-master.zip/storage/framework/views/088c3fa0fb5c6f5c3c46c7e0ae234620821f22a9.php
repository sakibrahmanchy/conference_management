<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" class = "active"><a href="#">Advertisements</a></li>
  <li role="presentation"><a href="<?php echo e(route('user.requests')); ?>">User Requests <span class="badge"><?php echo e($requests); ?></span></a></li>
  <li role="presentation"><a href="<?php echo e(route('allotments')); ?>">Allotments </a></li>
  <li role="presentation"><a href="<?php echo e(route('route.house.entry')); ?>"> House Entry </a></li>
</ul>