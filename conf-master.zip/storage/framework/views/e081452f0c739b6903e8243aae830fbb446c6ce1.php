<?php $__env->startSection('content'); ?>
<?php echo $__env->make("includes.conference_edit_header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; width:60%">
    <h2>Update Speaker</h2>

        <form action="<?php echo e(route('edit_speaker',["conference_id"=>$conference_id,"speaker_id"=>$speaker->id])); ?>" method="post" enctype="multipart/form-data">
                <div class="form-group" >
                   <label for="name">Name:</label>
                   <input class = "form-control" name="name" id="name"  placeholder="Name." value = "<?php echo e($speaker->name); ?>"><br>
                </div>
                <div class="form-group" >
                   <label for="venue">Profession:</label>
                   <textarea class = "form-control" name="profession" value = "<?php echo e($speaker->profession); ?>" id="profession" col="2" row="30"  placeholder="Profession."><?php echo e($speaker->profession); ?></textarea><br>
                </div>
                <div class="form-group" >
                   <label for="institute">Institute:</label>
                   <input class = "form-control" name="institute" value = "<?php echo e($speaker->institute); ?>" id="institute"  placeholder="Institute"><br>
                </div>
                <div class="form-group" >
                   <label for="address">Address:</label>
                    <input class = "form-control" name="address" value = "<?php echo e($speaker->address); ?>" id="address"  placeholder="Address"><br>
                </div>
                <div class="form_group" >
                   <label for="email">Email:</label>
                   <input class = "form-control" name="email" value = "<?php echo e($speaker->email); ?>" id="email"  placeholder="Email"><br>
                </div>
                <div class="form-group" >
                   <label for="biography">Biography:</label>
                   <textarea class = "form-control" name="biography" id="biography" col="2" row="30"  placeholder="Biography."><?php echo e($speaker->biography); ?></textarea><br>
                </div>

                <div class="form_group" >
                   <label for="image">Image:</label>
                    <img src="<?php echo e(route('speaker_image',['conference_id'=>$conference_id,'filename' => 'speaker-'.$speaker->id . '.jpg'])); ?>" alt="" class="img-responsive"/>
                   <input class = "form-control" name="image" id="image"  placeholder="Image" type="file"><br>
                </div>

                <button type = "submit" class = "btn btn-primary">Update Speaker</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
     </form>




</div>


<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>