<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" ><a href="">Dashboard</a></li>
  <li role="presentation" class = "active"><a href="<?php echo e(route('get_conferences')); ?>">Conferences <span class="badge"></span></a></li>
   <li role="presentation"><a href="<?php echo e(route('account')); ?>">Account <span class="badge"></span></a></li>
</ul>
<br>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
    <h2>Conference List</h2>
    <p>Manage your conferences!</p>
    <br><a style="float:right" class="btn btn-success" href="<?php echo e(route('create_conference')); ?>" target="_blank">New Conference</a><br><br><br>
    <?php foreach($conferenceList as $aConference): ?>

            <div class="col-md-4">
                <div class="thumbnail">
                    <img src=" <?php echo e(route('speaker_image',['conference_id'=>$aConference->id,'filename' => 'conference-cover-'.$aConference->id.'.jpg'])); ?>  " alt="ALT NAME" class="img-responsive" />
                    <div class="caption">
                         <h3><?php echo e($aConference->title); ?></h3>
                        <p>Conference_url: <a target="_blank" href="<?php echo e(route("conference_home",["conference_url"=>$aConference->conference_url])); ?>"><?php echo e($aConference->conference_url); ?></a></p>
                         <div class="row">
                         <div class="col-md-6">
                            <a href="<?php echo e(route('edit_conference',["conference_id"=>$aConference->id])); ?>" class="btn btn-primary btn-block">Edit</a>
                         </div>
                         <div class="col-md-6">
                            <a href="http://bootsnipp.com/" class="btn btn-primary btn-block">Delete</a></div>
                         </div>
                        </p>
                    </div>
                </div>
            </div>

    <?php endforeach; ?>

</div>

<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>