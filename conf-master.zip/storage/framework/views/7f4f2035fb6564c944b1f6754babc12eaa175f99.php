<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" ><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
  <li role="presentation"><a href="<?php echo e(route('account')); ?>">Account <span class="badge"></span></a></li>
   <li role="presentation" class = "active"><a href="">Contact <span class="badge"></span></a></li>
</ul>
<br>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; width:60%;">
 <form action="<?php echo e(route('post.notifications',['to'=>'admin'])); ?>" method="post">
                <div class="form-group" >
                   <h1>Contact Admin</h1><p>Contact our admin -panel for any type of enquiries.<p><br>
                   <label for="message">Message:</label>
                   <textarea class = "form-control" name="message" id="message" cols="2" rows = "5" placeholder="Your message for the admin."></textarea><br>

                </div>
                <button type = "submit" class = "btn btn-primary">Send Message</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
            </form>


</div>

</body>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>