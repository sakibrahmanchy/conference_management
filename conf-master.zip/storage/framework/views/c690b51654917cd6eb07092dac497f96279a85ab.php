<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <?php /*  <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">*/ ?>
        <link rel="stylesheet" href="<?php echo e(asset('bootstrap-3.3.7-dist/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('src/css/main.css')); ?>"/>
        <link rel="stylesheet" href="<?php echo e(asset('src/css/sweetalert.css')); ?>"/>
        <link rel="stylesheet" href="<?php echo e(asset('src/css/navbar-fixed-side.css')); ?> " />
        <link rel="stylesheet" href="<?php echo e(asset('src/css/bootstrap-datepicker.css')); ?> " />

        <script src="<?php echo e(URL::to('jquery/jquery-3.1.1.min.js')); ?>"></script>
        <script src="<?php echo e(URL::to('bootstrap-3.3.7-dist/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(URL::to('src/js/bootstrap-datepicker.js')); ?>"></script>
        <script src="<?php echo e(URL::to('src/ckeditor/ckeditor.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('src/arrow-0.1.9.min.js')); ?>">
        <style>

          .modal-dialog {
           margin-top: 10%;
          }
        </style>
        <script type="text/javascript">

  </script>

    </head>
    <div id = "container">
        <div id = "header">
            <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <body>
            <div class="container">
                <div class="content">
                <div class="title"><?php echo $__env->yieldContent('content'); ?></div>
                </div>
            </div>



                <script src="<?php echo e(URL::to('src/js/app.js')); ?>"></script>
                <script src="src/js/sweetalert.min.js"></script>

                <br>
                 <script>
                      <?php if(notify()->ready()): ?>
                        swal({
                            title:"<?php echo e(notify()->message()); ?>",
                            type:"<?php echo e(notify()->type()); ?>"
                        });
                      <?php endif; ?>
                </script>
        </body>
        <div id = "footer">
            <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
   </div>
</html>
