<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.conference_edit_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
    <h2>Track List</h2>
    <p>Manage your tracks!</p>
    <br><a style="float:right" class="btn btn-success" href="<?php echo e(route('create_track',['conference_id'=>$conference_id])); ?>">New Track</a><br><br><br>
    <?php $trackCounter = "1"; ?>
    <?php foreach($trackList as $aTrack): ?>
       <div class="panel-group" id="accordion" style="color:black   ">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title">
              <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($trackCounter); ?>">Track <?php echo e($trackCounter); ?>: <?php echo e($aTrack->track_name); ?> </a>
              <a style="float: right; color: #006dcc; margin-right: 5px; " href="<?php echo e(route('delete_track',["conference_id"=>$conference_id,"track_id"=>$aTrack->id])); ?>">Delete</a><span style="float:right">| </span>
              <a style="float: right; color: #006dcc;margin-right: 5px;" href="<?php echo e(route('edit_track',["conference_id"=>$conference_id,"track_id"=>$aTrack->id])); ?>" >Edit </a>
            </h4>
          </div>
          <div id="collapse<?php echo e($trackCounter++); ?>" class="panel-collapse collapse" >
            <div class="panel-body"><?php echo e($aTrack->description); ?>

            <br><br>
            <div class="col-md-6">
                <ul>
                <?php foreach($aTrack->scopes as $aScope): ?>
                    <li><?php echo e(@$aScope->name); ?>

                        <a style=" margin-left: 20px; color: #006dcc; margin-right: 5px; " href="<?php echo e(route('delete_scope',["conference_id"=>$conference_id,"scope_id"=>$aScope->id])); ?>">Delete</a>|
              <a style=" color: #006dcc;margin-right: 5px;" href="<?php echo e(route('edit_scope',["conference_id"=>$conference_id,"scope_id"=>$aScope->id])); ?>" >Edit</a>
                    </li>
                <?php endforeach; ?>
                <br><br>
                <li style="list-style-type: none"><a class="btn btn-primary" href="<?php echo e(route('create_scope',["conference_id"=>$conference_id,"track_id"=>$aTrack->id])); ?>" >New Scope</a></li>
                </ul>
                <br><br>

            </div>
            <div class="col-md-6 thumbnail">
               <img src="<?php echo e(route('track_image',['conference_id'=>$conference_id,'filename' => 'track-'.$aTrack->id . '.jpg'])); ?>" alt="" class="img-responsive"/>
            </div>
          </div>
        </div>
        </div>
    <?php endforeach; ?>

</div>


<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>