<?php $__env->startSection('content'); ?>


<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
    <?php if($notifications->isEmpty()): ?>
     <div class = "jumbotron" style = "background-color: #204d74; color: #f5f5f5;">
       <p>You have no notifications.</p>
     </div>
    <?php else: ?>
    <?php foreach($notifications as $notification): ?>
        <div class = "jumbotron" style = "background-color: #204d74; color: #f5f5f5; border: solid black 2px;">

            <p><?php echo e($notification->message); ?></p>
            From:  <p><?php echo e($notification->from); ?></p>
        </div>
    <?php endforeach; ?>
    <?php endif; ?>


</body>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>