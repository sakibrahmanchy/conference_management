<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" class = ""><a href="<?php echo e(route('admin.panel')); ?>">Advertisements</a></li>
  <li role="presentation" class = ""><a href="<?php echo e(route('user.requests')); ?>">User Requests <span class="badge"><?php echo e($requests); ?></span></a></li>
  <li role="presentation" class = "active"><a href="<?php echo e(route('allotments')); ?>">Allotment Requests</a></li>
  <li role="presentation"><a href="<?php echo e(route('route.house.entry')); ?>">HouseEntry </a></li>
</ul>

<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>

<div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <?php foreach($userRequests as $index=>$userRequest): ?>
         <li data-target="#myCarousel" data-slide-to="<?php echo e($index); ?>" class="active"></li>
      <?php endforeach; ?>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner jumbotron" role="listbox" style = "background-color:#204d74 ;color: #f5f5f5;">
       <center><h2> Requests for <?php echo e($housename); ?> </h2></center>
        <?php foreach($userRequests as $index=>$userRequest): ?>
                <div class="item <?php if($index==0): ?> <?php echo e('active'); ?> <?php endif; ?>">
                         <div class="col-sm-4 " style = " background-color:#204d74 ">
                         <p class="text-left"><h2><?php echo e($userRequest->name); ?></h2></p>
                         <?php if(Storage::disk('local')->has($userRequest->userID.'.jpg')): ?>
                                    <image src ="<?php echo e(route('account.image',['filename'=>$userRequest->userID.'.jpg'])); ?>" alt = "" class="img-responsive"></image>
                         <?php else: ?>
                            <image src ="<?php echo e(route('account.image',['filename'=>'default.jpg'])); ?>" alt = "" class="img-responsive"></image>
                         <?php endif; ?>
                        </div>
                        <div class="col-sm-4" style = "text-align: left; background-color:#204d74 ">
                            <p></p><br><br><br>
                             <p><b>Staff ID:</b> <?php echo e($userRequest->userID); ?></p>
                             <p><b>Department:</b> <?php echo e($userRequest->department); ?></p>
                             <p><b>Present Designation:</b> <?php echo e($userRequest->presentDesignation); ?></p>
                             <p><b>Points:</b>  <?php echo e($userRequest->point); ?></p>

                        </div>
                        <div class="col-sm-4" style = "text-align: left; background-color:#204d74 ">
                            <p></p><br><br><br><br>
                             <p><b>Marital Status:</b> <?php echo e($userRequest->maritalStatus); ?></p>
                             <p><b>Pay Scale:</b> <?php echo e($userRequest->payScale); ?></p>
                             <p><b>Phone:</b> <?php echo e($userRequest->phone); ?></p><br>
                             <a href="<?php echo e(route('allotment.accept',['userid'=>$userRequest->userID,'houseName'=>$userRequest->houseName])); ?>" type = "button" class = "btn btn-primary">Accept</a>
                            <a href="<?php echo e(route('allotment.reject',['userid'=>$userRequest->userID,'houseName'=>$userRequest->houseName])); ?>" type = "button" class = "btn btn-primary">Reject</a><br><br>
                        </div>



                </div>
        <?php endforeach; ?>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

</body>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>