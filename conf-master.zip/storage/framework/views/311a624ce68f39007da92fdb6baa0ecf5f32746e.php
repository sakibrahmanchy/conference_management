<?php $__env->startSection('content'); ?>

<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
    <h2>Conference List</h2>

    <?php foreach($conferenceList as $aConference): ?>

            <div class="col-md-4">
                <div class="thumbnail">
                    <img height="50px" src=" <?php echo e(route('speaker_image',['conference_id'=>$aConference->id,'filename' => 'conference-cover-'.$aConference->id.'.jpg'])); ?>  " alt="ALT NAME" class="img-responsive" />
                    <div class="caption">
                         <h3><?php echo e($aConference->title); ?></h3>
                        <p>Conference_url: <a target="_blank" href="<?php echo e(route("conference_home",["conference_url"=>$aConference->conference_url])); ?>"><?php echo e($aConference->conference_url); ?></a></p></p>
                    </div>
                </div>
            </div>

    <?php endforeach; ?>

</div>

<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>