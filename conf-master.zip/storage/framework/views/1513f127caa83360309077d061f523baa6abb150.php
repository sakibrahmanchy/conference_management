<html>


<nav class="navbar navbar-default"  style = "height: 40px; background-color: #204d74; color:white" >
  <div class="container-fluid" >

 <a style="color:#ffffff" class="navbar-brand" <?php if(session('admin')=="true"): ?> href="<?php echo e(route('admin.panel')); ?>" <?php else: ?> href="<?php echo e(route('dashboard')); ?>" <?php endif; ?>>
 Housing Distribution</a>


    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav navbar-right">
         <?php if(Auth::check()||session('admin')=="true"): ?>
                <li> <a style="color:#ffffff" href="<?php echo e(route('getNotifications')); ?>" >Notifications</a></li>
               <li> <a style="color:#ffffff" href="<?php echo e(route('logout')); ?>" >Logout</a></li>
         <?php endif; ?>

      </ul>
    </div>
  </div>
</nav>
</html>