<ul class="nav nav-pills <?php /*<?php if(isset($bodySize)&&$bodySize==60): ?>*/ ?> col-md-offset-1<?php /* <?php endif; ?>*/ ?>" role="tablist">
   <li role="presentation" <?php if($pageTitle=="basic"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('edit_conference',['conference_id'=>$conference_id])); ?>">Basic information</a></li>
   <li role="presentation" <?php if($pageTitle=="dates"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('edit_conference_dates',['conference_id'=>$conference_id])); ?>">Important Dates</a></li>
   <li role="presentation" <?php if($pageTitle=="terms"): ?> class = "active" <?php endif; ?>><a href="<?php echo e(route('edit_conference_terms',['conference_id'=>$conference_id])); ?>">Terms and Policy<span class="badge"></span></a></li>
   <li role="presentation" <?php if($pageTitle=="speaker"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('speaker_list',['conference_id'=>$conference_id])); ?>">Speakers <span class="badge"></span></a></li>
   <li role="presentation" <?php if($pageTitle=="track"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('track_list',['conference_id'=>$conference_id])); ?>">Tracks & Scopes<span class="badge"></span></a></li>
   <li role="presentation" <?php if($pageTitle=="committee"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('committee_list',['conference_id'=>$conference_id])); ?>">Committee<span class="badge"></span></a></li>
   <li role="presentation" <?php if($pageTitle=="reviewer"): ?> class = "active" <?php endif; ?> ><a href="<?php echo e(route('reviewer_list',['conference_id'=>$conference_id])); ?>">Reviewers<span class="badge"></span></a></li>
    <li role="presentation" <?php if($pageTitle=="submissions"): ?> class = "active" <?php endif; ?>><a href="<?php echo e(route("submissions_show",["conference_id"=>$conference_id ])); ?>" >Submissions</a></li>
    <li role="presentation" <?php if($pageTitle=="reviews"): ?> class = "active" <?php endif; ?>><a href="<?php echo e(route("submissions_judge",["conference_id"=>$conference_id ])); ?>" >Reviews</a></li>
</ul>
<br>
