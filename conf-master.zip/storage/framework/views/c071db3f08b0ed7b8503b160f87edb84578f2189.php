<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" ><a href="">Basic information</a></li>
  <li role="presentation" class = "active"><a href="<?php echo e(route('speaker_list')); ?>">Speakers <span class="badge"></span></a></li>
   <li role="presentation"><a href="<?php echo e(route('getContact')); ?>">Committee <span class="badge"></span></a></li>
   <li role="presentation"><a href="<?php echo e(route('getContact')); ?>">Terms and Legal Information<span class="badge"></span></a></li>
</ul>
<br>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
    <h2>Speaker List</h2>
    <p>Manage your speakers!</p>
    <br><a style="float:right" class="btn btn-success" data-toggle="modal" data-target="#speakerCreateModal">New Speaker</a><br><br><br>
    <?php foreach($speakerList as $aSpeaker): ?>

            <div class="col-md-4">
                <div class="thumbnail">
                    <img src="http://placehold.it/320x200" alt="ALT NAME" class="img-responsive" />
                    <div class="caption">
                         <h3><?php echo e($aSpeaker->name); ?></h3>
                        <p><?php echo e($aSpeaker->profession); ?></p>
                        <p><?php echo e($aSpeaker->institute); ?></p>
                         <div class="row">
                         <div class="col-md-6">
                            <a href="<?php echo e(route('edit_speaker',["speaker_id"=>$aSpeaker->id])); ?>" class="btn btn-primary btn-block">Edit</a>
                         </div>
                         <div class="col-md-6">
                            <a href="<?php echo e(route('delete_speaker',["speaker_id"=>$aSpeaker->id])); ?>" class="btn btn-primary btn-block">Delete</a></div>
                         </div>
                        </p>
                    </div>
                </div>
            </div>

    <?php endforeach; ?>

</div>

<div id="speakerCreateModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Create a speaker</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('create_speaker')); ?>" method="post">
                <div class="form-group" >
                   <label for="name">Name:</label>
                   <input class = "form-control" name="name" id="name"  placeholder="Name."><br>
                </div>
                <div class="form-group" >
                   <label for="venue">Profession:</label>
                   <textarea class = "form-control" name="profession" id="profession" col="2" row="30"  placeholder="Profession."></textarea><br>
                </div>
                <div class="form-group" >
                   <label for="institute">Institute:</label>
                   <input class = "form-control" name="institute" id="institute"  placeholder="Institute"><br>
                </div>
                <div class="form-group" >
                   <label for="address">Address:</label>
                    <input class = "form-control" name="address" id="address"  placeholder="Address"><br>
                </div>
                <div class="form_group" >
                   <label for="email">Email:</label>
                   <input class = "form-control" name="email" id="email"  placeholder="Email"><br>
                </div>
                <div class="form-group" >
                   <label for="biography">Biography:</label>
                   <textarea class = "form-control" name="biography" id="biography" col="2" row="30"  placeholder="Biography."></textarea><br>
                </div>


                <button type = "submit" class = "btn btn-primary">Create Speaker</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
     </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>



<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>