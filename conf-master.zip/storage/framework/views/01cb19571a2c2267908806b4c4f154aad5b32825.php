<?php $__env->startSection('title'); ?>
  Welcome!
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row jumbotron" style = "background-color: #204d74; color: #f5f5f5; "  >
    <div class="col-md-6">
      <form action="<?php echo e(route('signup')); ?>" method = "post">
        <h3>Sign Up</h3>
        <div class="form-group <?php echo e($errors->has('id')?'has-error':''); ?>" >
            <label for="id">Your ID</label>
            <input class ="form-control" type="text" name = "id" id = "id" value = "<?php echo e(Request::old('id')); ?>"/>
        </div>
        <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>">
            <label for="name">Your Name</label>
            <input class ="form-control" type="text" name = "name" id = "name" value = "<?php echo e(Request::old('name')); ?>"/>
        </div>
        <div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>" >
            <label for="password">Your Password</label>
            <input class ="form-control" type="password" name = "password" id = "password" />
        </div>
        <button type = "submit" class = "btn btn-primary">Submit</button>
        <input type="hidden" name = "_token" value = "<?php echo e(Session::token()); ?>"/>
      </form>
    </div>
    <div class="col-md-6">
      <form action="<?php echo e(route('signin')); ?>" method = "post">
        <h3>Sign In</h3>
        <div class="form-group <?php echo e($errors->has('id')?'has-error':''); ?>">
            <label for="id">Your ID</label>
            <input class ="form-control" type="text" name = "id" id = "id" value = "<?php echo e(Request::old('id')); ?>"/>
         </div>
        <div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>" >
            <label for="password">Your Password</label>
            <input class ="form-control" type="password" name = "password" id = "password"/>
        </div>
        <button type = "submit" class = "btn btn-primary">Submit</button>
        <input type="hidden" name = "_token" value = "<?php echo e(Session::token()); ?>"/>
      </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>