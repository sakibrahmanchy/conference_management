<?php $__env->startSection('content'); ?>

<div class = "jumbotron">
<h1>Thank you very much!!</h1>.<p class = "alert alert-success"> Your request has been sent to admin. Please visit us again for confirmation!!</p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>