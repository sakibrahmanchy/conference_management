<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.conference_edit_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5;">
    <h2>Important Terms</h2>
    <p>Customize important terms for your conference!</p>

           <form action="<?php echo e(route('edit_conference_terms',["conference_id"=>$conference->id])); ?>" method="post">

                <div class="form-group" >
                   <label for="submission_guideline">Submission Guideline:</label>
                   <textarea class = "form-control" name="submission_guideline" id="submission_guideline" col="2" row="30"  ><?php echo e($conference->submission_guideline); ?></textarea><br>
                </div>
                <div class="form-group" >
                   <label for="plagiarism_policy">Plagiarism Policy</label>
                   <textarea class = "form-control" name="plagiarism_policy" id="plagiarism_policy" col="2" row="30"  ><?php echo e($conference->plagiarism_policy); ?></textarea><br>
                </div>
                <div class="form-group" >
                   <label for="review_policy">Review Policy:</label>
                   <textarea class = "form-control" name="review_policy" id="review_policy" col="2" row="30"  ><?php echo e($conference->review_policy); ?></textarea><br>
                </div>
                <div class="form-group" >
                   <label for="best_paper_award">Best Paper <Award></Award>:</label>
                   <textarea class = "form-control" name="best_paper_award" id="best_paper_award" col="2" row="30"  ><?php echo e($conference->best_paper_award); ?></textarea><br>
                </div>

                <button type = "submit" class = "btn btn-primary">Save Changes</button>
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>"/>
     </form>



</div>

<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

        CKEDITOR.replace('submission_guideline');
        CKEDITOR.replace('plagiarism_policy');
        CKEDITOR.replace('review_policy');
        CKEDITOR.replace('best_paper_award');

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>