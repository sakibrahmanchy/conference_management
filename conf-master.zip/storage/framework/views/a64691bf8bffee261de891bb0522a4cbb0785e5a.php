<?php $__env->startSection('title'); ?>
  Admin Section
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div>
    <div>
      <form action="<?php echo e(route('admin.verify')); ?>" method = "post">
        <div class = "jumbotron" >
            <div class="text-center">
                <h1>Admin Login Page</h1>
                <p class = "alert alert-warning"> This is only for admins. Please verify yourself before entering.</p>
            </div>
        </div>

        <div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>" >
            <label for="password">Admin`s Password</label>
            <input class ="form-control" type="password" name = "password" id = "password" />
        </div>
        <button type = "submit" class = "btn btn-primary">Submit</button>
        <input type="hidden" name = "_token" value = "<?php echo e(Session::token()); ?>"/>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>