<?php $__env->startSection('content'); ?>
<ul class="nav nav-pills col-md-offset-3" role="tablist">
  <li role="presentation" class = ""><a href="<?php echo e(route('admin.panel')); ?>">Advertisements</a></li>
  <li role="presentation" class = ""><a href="<?php echo e(route('user.requests')); ?>">User Requests <span class="badge"><?php echo e($requests); ?></span></a></li>
  <li role="presentation" class = "active"><a href="#">Allotment Requests</a></li>
  <li role="presentation"><a href="<?php echo e(route('route.house.entry')); ?>">HouseEntry </a></li>
</ul>

<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<br>
<div class="container jumbotron"  style = "background-color:#204d74 ;color:white;font-size:20px">
        <?php foreach($userRequests as $index=>$userRequest): ?>
                 <div>
                           <div class="container col-sm-4">
                                <h2>House: <?php echo e($userRequest->houseName); ?></h2>
                                <p><?php echo e($userRequest->houseType); ?></p>
                                <a href = "<?php echo e(route('sorted.users',['housename'=>$userRequest->houseName])); ?>" type="button" class="btn btn-info">View Requests</a>
                           </div>

                 </div>
        <?php endforeach; ?>
</div>


</body>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>