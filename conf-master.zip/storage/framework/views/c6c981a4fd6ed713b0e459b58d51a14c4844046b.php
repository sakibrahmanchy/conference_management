<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.conference_edit_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body>
<div class="container jumbotron" style = "background-color: #204d74; color: #f5f5f5; ">
    <h2>Reviewer List</h2>
    <p>Manage your reviewers!</p>
    <br><a style="float:right" class="btn btn-success" href="<?php echo e(route('create_reviewer',['conference_id'=>$conference_id])); ?>">New Reviewer</a><br><br><br>
    <?php foreach($reviewerList as $aReviewer): ?>

            <div class="col-md-4">
                <div class="thumbnail">
                     <img src="<?php echo e(route('reviewer_image',['conference_id'=>$conference_id,'filename' => 'reviewer-'.$aReviewer->id . '.jpg'])); ?>" alt="" class="img-responsive"/>
                    <div class="caption">
                         <h3><?php echo e($aReviewer->name); ?></h3>
                        <p><?php echo e($aReviewer->phone); ?></p>
                        <div class="row">
                         <div class="col-md-6">
                            <a href="<?php echo e(route('edit_reviewer',["conference_id"=>$conference_id,"reviewer_id"=>$aReviewer->id])); ?>" class="btn btn-primary btn-block">Edit</a>
                         </div>
                         <div class="col-md-6">
                            <a href="<?php echo e(route('delete_reviewer',["reviewer_id"=>$aReviewer->id,"conference_id"=>$conference_id])); ?>" class="btn btn-primary btn-block">Delete</a></div>
                         </div>
                        </p>
                    </div>
                </div>
            </div>

    <?php endforeach; ?>

</div>


<script>
 $(document).ready(function(){
        $('.datepicker').datepicker({
            orientation: "bottom",
            autoclose: true,
            format: 'yyyy/mm/dd'
        });

 });


</script>



</body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>